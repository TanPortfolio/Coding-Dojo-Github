for x in range(0, 1000001):
    if (x % 5 == 0):
        print x